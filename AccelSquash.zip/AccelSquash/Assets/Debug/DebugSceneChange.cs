﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DebugSceneChange : MonoBehaviour
{
    public int index = 0;
    void Update()
    {
        if ( Input.GetMouseButtonDown(0) )
        {
            FadeManagerScript.Instance.FadeStart(index);
        }
    }
}
