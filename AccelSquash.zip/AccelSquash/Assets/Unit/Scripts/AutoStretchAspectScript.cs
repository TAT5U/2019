﻿using UnityEngine;

[ExecuteInEditMode]
public class AutoStretchAspectScript : MonoBehaviour 
{
	[SerializeField, Tooltip("Canvasの「Reference Resolution」の比率と同じ設定にしてください")]
	private Vector2 aspect_ = new Vector2(4.0f, 3.0f);


	private float aspectRate_ = 0.0f;


	private void Awake()
	{
		aspectRate_ = (float)aspect_.x / aspect_.y;

		#if UNITY_EDITOR
		if (!UnityEditor.EditorApplication.isPlaying) return;
		#endif



		StretchAspect();
	}

	private void Update()
	{
		if (IsChangeAspect) return;

		StretchAspect();
		GetComponent<Camera>().ResetAspect();
	}


	private void StretchAspect()
	{
		float baseAspect = aspect_.y / aspect_.x;
		float updateAspect = (float)Screen.height / Screen.width;
		float stretchAspect = 0.0f;

		if (baseAspect > updateAspect)
		{
			stretchAspect = updateAspect / baseAspect;
			GetComponent<Camera>().rect = new Rect((1.0f - stretchAspect) * 0.50f, 0.0f, stretchAspect, 1.0f);
		}
		else
		{
			stretchAspect = baseAspect / updateAspect;
			GetComponent<Camera>().rect = new Rect(0.0f, (1.0f - stretchAspect) * 0.50f, 1.0f, stretchAspect);
		}
	}


	private bool IsChangeAspect
	{
		get
		{
			return GetComponent<Camera>().aspect == aspectRate_;
		}
	}
}
