﻿using UnityEngine;

public class CustomReadOnlyAttribute : PropertyAttribute 
{
}
