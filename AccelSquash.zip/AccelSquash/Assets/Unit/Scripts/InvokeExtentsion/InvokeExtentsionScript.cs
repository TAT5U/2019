﻿using System;
using System.Collections;
using UnityEngine;

public static class InvokeExtentsionScript
{
	public static IEnumerator InvokeEx(this MonoBehaviour monoBehaviour, float waitTime, Action action)
	{
		yield return new WaitForSeconds(waitTime);
		action();
	}

	public static IEnumerator InvokeExRealTimeUpdate(this MonoBehaviour monoBehaviour, Action action)
	{
		yield return null;
		action();
	}


	public static IEnumerator InvokeEx<T>(this MonoBehaviour monoBehaviour, float waitTime, Action<T> action, T argT)
	{
		yield return new WaitForSeconds(waitTime);
		action(argT);
	}

	public static IEnumerator InvokeExRealTimeUpdate<T>(this MonoBehaviour monoBehaviour, Action<T> action, T argT)
	{
		yield return null;
		action(argT);
	}
}
