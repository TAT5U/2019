﻿using UnityEngine;


// Bloomの仕組みとしては
// 最初にthreshold_より大きい明度の部分を抽出し、
// ぼかし処理をしながら加算していき、
// 最後に元のテクスチャと合成することで表現している
// ぼかし処理は解像度を段階的に落としながら、元の大きさでレンダリング
// することで表現している(ダウンサンプリングとアップサンプリング)
// 参考URL -> http://light11.hatenadiary.com/entry/2018/03/15/000022


[ExecuteInEditMode]
public class BloomManagerScript : MonoBehaviour
{
	[SerializeField, Range(0.0f, 1.0f), Tooltip("理想値(StencilBloom使用が前提条件)は0.50")]
	private float threshold_ = 0.50f;

	[SerializeField, Range(0.0f, 10.0f), Tooltip("理想値(StencilBloom使用が前提条件)は2.50")]
	private float intensity_ = 2.50f;

	[SerializeField, Range(1, 64)]
	private int blur_ = 20;


	[SerializeField]
	private Material bloomMaterial_;


	// 本来はサンプリング回数を設定できるようにすべきだが、
	// 今回はそこまでサンプリングを行わないので固定にする
	private int kSamplingMax = 10;

	private int samplingCount_ = 0;


	private RenderTexture[] renderTextures_ = new RenderTexture[10];


	[ImageEffectOpaque]
	void OnRenderImage(RenderTexture source, RenderTexture dest)
	{
		RenderTexture tmpTexture = RenderTexture.GetTemporary(source.width, source.height, 0, RenderTextureFormat.ARGB32);
		tmpTexture.filterMode = FilterMode.Bilinear;


		bloomMaterial_.SetTexture("mainTex_", source);
		bloomMaterial_.SetTexture("sourceTex_", source);
		bloomMaterial_.SetTexture("tmpTex_", tmpTexture);

		bloomMaterial_.SetInt("blur_", blur_);

		bloomMaterial_.SetFloat("threshold_", threshold_);
		bloomMaterial_.SetFloat("intensity_", intensity_);
		bloomMaterial_.SetFloat("threshold_", threshold_);
		bloomMaterial_.SetFloat("intensity_", intensity_);


		int width  = source.width;
		int height = source.height;

		int pathIndex = 0;

		RenderTexture currentSource = source;
		RenderTexture currentDest = null;

		samplingCount_ = 0;


		// ダウンサンプリング
		while (samplingCount_ < kSamplingMax)
		{
			// 少しずつ小さくする
			width  /= 2;
			height /= 2;
			if (width < 2 || height < 2) break;


			// デプスバッファは0に設定
			currentDest = renderTextures_[samplingCount_] = RenderTexture.GetTemporary(width, height, 0, source.format);

			bloomMaterial_.SetTexture("mainTex_", currentSource);


			// 最初のみ明度抽出
			pathIndex = (samplingCount_ <= 0 ? 0 : 1);
			Graphics.Blit(currentSource, currentDest, bloomMaterial_, pathIndex);

			currentSource = currentDest;

			samplingCount_++;
		}



		// RenderTexture.GetTemporaryで取得したRenderTexture
		// を格納すると同じTmpとして渡される
		// つまりRenderTexture.ReleaseTemporaryで格納した
		// RenderTextureも開放される
		renderTextures_[samplingCount_ - 1] = null;


		// 配列の最後尾から行うと
		// RenderTextureのテクスチャが被り、
		// 一度リリースされたものが入りエラーになるので
		// 配列の最後尾の1つ前からアップサンプリングを行う
		samplingCount_ -= 2;



		// アップサンプリング
		while (samplingCount_ >= 0)
		{
			currentDest = renderTextures_[samplingCount_];
			renderTextures_[samplingCount_] = null;

			bloomMaterial_.SetTexture("mainTex_", currentSource);

		
			// Blit時にマテリアルとパスを指定する
			Graphics.Blit(currentSource, currentDest, bloomMaterial_, 2);


			RenderTexture.ReleaseTemporary(currentSource);
			currentSource = currentDest;

			samplingCount_--;
		}


		GetComponent<Camera>().targetTexture = null;


		// 仕上げ
		Graphics.Blit(currentSource, dest,  bloomMaterial_, 3);


		// 解放処理
		RenderTexture.ReleaseTemporary(currentSource);
	}
}
