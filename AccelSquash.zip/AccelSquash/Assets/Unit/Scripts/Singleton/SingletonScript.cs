﻿using UnityEngine;

public abstract class SingletonScript<ClassType> : MonoBehaviour where ClassType : SingletonScript<ClassType> 
{
	protected enum ObjectInstanceState
	{
		Attached,
		NoAttached,
		ThisAttached
	}


	private static ClassType instance_;


	public static ClassType Instance
	{
		get
		{
			if (instance_ == null)
			{
				instance_ = (ClassType)FindObjectOfType(typeof(ClassType));

				if (instance_ == null)
				{
					Debug.LogError("Error: No GameObject Attaching " + typeof(ClassType));
				}
			}
			return instance_;
		}
	}


	// HACK: シングルトンはDestroyされないオブジェクトにするべき
	// 		 ただインスタンス化するためにも利用されるため
	// 		 正規のシングルトンなら継承先でDontDestroyOnLoadを記述する
	protected virtual void Awake()
	{
		switch (CheckInstanceState())
		{
			case ObjectInstanceState.NoAttached:
				instance_ = (ClassType)this;
				break;
			case ObjectInstanceState.Attached:
				Destroy(this);
				break;
		}
	}

	protected ObjectInstanceState CheckInstanceState()
	{
		if (instance_ == null)
		{
			return ObjectInstanceState.NoAttached;
		}
		else if (Instance == this)
		{
			return ObjectInstanceState.ThisAttached;
		}
		return ObjectInstanceState.Attached;
	}


	protected virtual void OnDestroy()
	{
		Destroy(gameObject);
	}
}