﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGMManagerScript : SoundManagerScript<BGMManagerScript> 
{
	public enum BGMType
	{
		NormalBGM = 0,
		BossBGM	  = 1
	}


	protected override void Awake()
	{
		base.Awake();

		SoundPlay(0, true);
	}
}
