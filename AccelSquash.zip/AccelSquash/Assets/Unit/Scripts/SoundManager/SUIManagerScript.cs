﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SUIManagerScript : SoundManagerScript<SUIManagerScript> 
{
	protected override void Awake()
	{
		base.Awake();
	}
}
