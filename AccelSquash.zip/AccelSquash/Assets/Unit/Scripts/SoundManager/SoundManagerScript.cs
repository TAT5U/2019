﻿using System.Collections.Generic;
using UnityEngine;

// HACK: 継承の構文がNG
// 		 Singletonを継承してそれをさらに継承させている
// 		 Singletonを実装してそこにこのScriptの内容を実装しているような形
// 		 継承しているおかげか、このScript自体はアタッチできないので多重にはなっていない(多分)
// 		 AudioClip・AudioSourceがそれぞれ必要になるため継承で分けている
// TODO: 簡易化

[RequireComponent(typeof(AudioSource))]
public class SoundManagerScript<SoundManagerType> : SingletonScript<SoundManagerType> where SoundManagerType : SoundManagerScript<SoundManagerType>
{
	[SerializeField]
	private List<AudioClip> soundClip_;


	protected AudioSource sound_;

	// 2019-01-16
	// Tatsuya Add
	private bool isDelay_ = false;

	// 2019-01-16
	// Tatsuya Add
	private float delayTime_ = 0.0f;

	// 2019-01-16
	// Tatsuya Add
	private float delayCountTime_ = 0.0f;


	// 2019-01-22
	// Tatsuya Add
	private int soundIndex_ = 0;


	// 2019-01-22
	// Tatsuya Add
	private bool isFade_ = false;


	// 2019-01-22
	// Tatsuya Add
	private int nextSountIndex_ = 0;



	private bool isComply_ = false;


	protected override void Awake()
	{
		base.Awake();

		sound_ = GetComponent<AudioSource>();
		sound_.playOnAwake = false;

		DontDestroyOnLoad(transform.root.gameObject);
	}


	// 2019-01-16
	// Tatsuya Add
	private void Update()
	{
		if (isComply_)
		{
			if (!sound_.isPlaying)
			{
				isComply_ = false;
			}
		}

		if (isFade_)
		{
			sound_.volume -= Time.deltaTime;


			if (sound_.volume > 0.0f) return;
			SoundPlay(nextSountIndex_, true);

			isFade_ = false;
		}
		else
		{
			sound_.volume += Time.deltaTime;
		}



		if (!isDelay_) return;
		delayCountTime_ += Time.deltaTime;

		if (delayCountTime_ >= delayTime_)
		{
			delayTime_ = 0.0f;
			delayCountTime_ = 0.0f;
			isDelay_ = false;
		}
	}


	// 2019-01-16
	// Tatsuya Changed
	//public void SoundPlay(int soundIndex = 0, bool isBGM = false)
	//{
	//	if (soundIndex > soundClip_.Count - 1) return;

	//	try
	//	{
	//		if (sound_ == null)
	//		{
	//			sound_ = GetComponent<AudioSource>();
	//			sound_.playOnAwake = false;
	//		}

	//		sound_.clip = soundClip_[soundIndex];
	//		sound_.Play();

	//		if (isBGM)
	//		{
	//			sound_.loop = true;
	//		}
	//		else
	//		{
	//			sound_.loop = false;
	//		}
	//	}
	//	catch (System.Exception ex)
	//	{
	//		Debug.LogError("Sound Error");
	//	}
	//}

	/// <summary>
	/// Sound Play
	/// isFadeはBGMのみ適用可
	/// </summary>
	public void SoundPlay(int soundIndex = 0, bool isBGM = false, bool isFade = false, float delayTime = 0.0f, bool isComply = false)
	{
		if (!isComply)
		{
			if (soundIndex > soundClip_.Count - 1 || isDelay_ || isComply_) return;
		}


		try
		{
			if (sound_ == null)
			{
				sound_ = GetComponent<AudioSource>();
				sound_.playOnAwake = false;
			}

			if (isFade && isBGM)
			{
				isFade_ = isFade;
				nextSountIndex_ = soundIndex;
				return;
			}


			// 2019-01-22
			// Tatsuya Add
			soundIndex_ = soundIndex;


			sound_.clip = soundClip_[soundIndex];
			sound_.Play();

			if (isBGM)
			{
				sound_.loop = true;
			}
			else
			{
				sound_.loop = false;
			}

			if (isComply)
			{
				isComply_ = true;
			}
			else
			{
				isComply_ = false;
			}



			if (delayTime <= 0.0f) return;

			delayTime_ = delayTime;
			delayCountTime_ = 0.0f;
			isDelay_ = true;
		}
		catch (System.Exception ex)
		{
			Debug.LogError("Sound Error");
		}
	}


	public void SetMute(bool isMute)
	{
		if (sound_ == null)
		{
			sound_ = GetComponent<AudioSource>();
			sound_.playOnAwake = false;
		}
		sound_.mute = isMute;
	}


	public int GetSoundIndex
	{
		get
		{
			return soundIndex_;
		}
	}


	protected override void OnDestroy()
	{
		Debug.Log("Destroy");
		Destroy(transform.root.gameObject);
	}
}

