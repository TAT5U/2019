﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FadeCameraRenderScript : MonoBehaviour 
{
	private Material fadeMaterial_;

	private void OnRenderImage(RenderTexture source, RenderTexture dest)
	{
		if (fadeMaterial_ == null)
		{
			Graphics.Blit(source, dest);
		}
		else
		{
			fadeMaterial_.SetTexture("fadeTex_", source);
			Graphics.Blit(source, dest, fadeMaterial_);
		}
	}


	public void SetMaterial(Material fadeMaterial)
	{
		fadeMaterial_ = fadeMaterial;
	}
}
