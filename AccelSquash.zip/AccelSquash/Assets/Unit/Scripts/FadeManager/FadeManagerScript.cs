﻿using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using UnityEngine.UI;
using System.Collections;


public class FadeManagerScript : SingletonScript<FadeManagerScript> 
{
	[SerializeField]
	private bool isMultiple_ = false;

	[SerializeField]
	private bool isFadeAlphaCustom_ = false;

	[SerializeField]
	private bool isStartFadeTransclucent_ = false;

	[SerializeField]
	private Canvas fadeTransclucentCanvas_;


	[SerializeField]
	private Camera fadeTargetCamera_;


	[SerializeField]
	private List<Canvas> fadeTargetCanvasList_ = new List<Canvas>();


	[SerializeField]
	private Material fadeMaterial_;


	[SerializeField, SceneName]
	private string[] sceneName_ = new string[1];

	[SerializeField, Range(0.0f, 0.10f)]
	private float fadeOutSpeed_ = 0.020f;

	[SerializeField, Range(0.0f, 0.10f)]
	private float fadeInSpeed_  = 0.040f;

	[SerializeField]
	private Color fadeColor_ = Color.black;

	[SerializeField, Range(0.0f, 1.0f)]
	private float alpha_ = 1.0f;


	private bool isFadeOn_	 = false;
	private bool isPreLoad_	 = false;

	private int sceneNumber_ = 0;


	private AsyncOperation asyncOperation_ = null;


	#if UNITY_EDITOR
	private void OnValidate()
	{
		if (!isMultiple_)
		{
			System.Array.Resize(ref sceneName_, 1);
		}

		if (!isFadeAlphaCustom_ && !isStartFadeTransclucent_) 
		{
			alpha_ = 1.0f;
		}

		if (!isStartFadeTransclucent_) 
		{
			fadeTransclucentCanvas_ = null;
		}


		if (isFadeAlphaCustom_ && isStartFadeTransclucent_) 
		{
			isFadeAlphaCustom_ = false;
			isStartFadeTransclucent_ = false;
			alpha_ = 1.0f;
			fadeTransclucentCanvas_ = null;
		}
	}
	#endif



	// HACK: 継承・Singletonとして適切ではない
	// 		 通常のSingletonの挙動ではないため継承元を呼んでいない
	// 		 呼んでしまうと遷移分岐ができなくなる(Inspector上で設定しているため)
	protected override void Awake()
	{
		fadeColor_.a = 0.0f;


		DontDestroyOnLoad(gameObject);

		CheckInstanceState();


		if (isStartFadeTransclucent_) 
		{
			Canvas transclucentCanvas = Instantiate(fadeTransclucentCanvas_);
			Color transclucentCanvasColor = transclucentCanvas.GetComponentInChildren<Image> ().color;
			transclucentCanvasColor = fadeColor_;
			transclucentCanvasColor.a = alpha_;

			transclucentCanvas.GetComponentInChildren<Image>().color = transclucentCanvasColor;
			SetFadeCanvas (transclucentCanvas);
		}
	}


	private void Update()
	{
		int fadeTargetCanvasCount = 0;

		if (CheckInstanceState() == ObjectInstanceState.Attached)
		{
			while (fadeTargetCanvasCount < fadeTargetCanvasList_.Count)
			{
				if (fadeTargetCanvasList_[fadeTargetCanvasCount] != null)
				{
					if (fadeTargetCanvasList_[fadeTargetCanvasCount].GetComponent<CanvasGroup>() == null)
					{
						fadeTargetCanvasList_[fadeTargetCanvasCount].gameObject.AddComponent<CanvasGroup>();
					}
					fadeTargetCanvasList_[fadeTargetCanvasCount].GetComponent<CanvasGroup>().alpha = (1 - Instance.fadeColor_.a);
				}

				fadeTargetCanvasCount++;
			}

			fadeTargetCanvasCount = 0;
		}
		else
		{
			while (fadeTargetCanvasCount < fadeTargetCanvasList_.Count)
			{
				if (fadeTargetCanvasList_[fadeTargetCanvasCount] != null)
				{
					if (fadeTargetCanvasList_[fadeTargetCanvasCount].GetComponent<CanvasGroup>() == null)
					{
						fadeTargetCanvasList_[fadeTargetCanvasCount].gameObject.AddComponent<CanvasGroup>();
					}
					fadeTargetCanvasList_[fadeTargetCanvasCount].GetComponent<CanvasGroup>().alpha = (1 - fadeColor_.a);
				}

				fadeTargetCanvasCount++;
			}

			fadeTargetCanvasCount = 0;
		}




		if (!IsFade) return;

		fadeMaterial_.SetColor ("fadeColor_", fadeColor_);
		SetCameraMaterial (fadeMaterial_);
	}


	public void FadeStart(int sceneNumber = 0)
	{
		if (IsFade || isPreLoad_) return;
		ExceptionDetection(sceneNumber);
		sceneNumber_ = sceneNumber;
		ScenePreLoad();
		FadeOut();
	}


	private void FadeOut()
	{
		// HACK: 本来ここに記述すべきじゃない
		// 		 Awakeで一度設定するのでFadeされないことがあるため記述
		// 		 すぐにFadeするとバグが発生する可能性がある
		if (!isFadeAlphaCustom_) 
		{
			alpha_ = 1.0f;
		}


		if (fadeColor_.a >= alpha_)
		{
			SetFade(false);

			StartCoroutine(SceneChange());
			return;
		}

		SetFade(true);
		fadeColor_.a += fadeOutSpeed_;
		StartCoroutine(this.InvokeExRealTimeUpdate(FadeOut));
	}


	private void ScenePreLoad()
	{
		asyncOperation_ = SceneManager.LoadSceneAsync(sceneName_[sceneNumber_]);
		asyncOperation_.allowSceneActivation = false;
		isPreLoad_ = true;
	}

	private IEnumerator SceneChange()
	{
		if (!IsFade)
		{
			// 非同期読み込みは0.90f(90%)までしか読み込めない
			while (asyncOperation_.progress < 0.90f)
			{
				yield return null;
			}

			asyncOperation_.allowSceneActivation = true;
			yield return asyncOperation_;
		}


		if (!isFadeAlphaCustom_) 
		{
			FadeIn();
		} 
		else 
		{
			FadeManagerDestroy();
		}
	}

	private void FadeIn()
	{
		if (fadeColor_.a <= 0.0f)
		{
			SetFade(false);
			FadeManagerDestroy();
			return;
		}

		SetFade(true);
		fadeColor_.a -= fadeInSpeed_;
		StartCoroutine(this.InvokeExRealTimeUpdate(FadeIn));
	}


	private void FadeManagerDestroy()
	{
		if (IsFade) return;

		SetCameraMaterial (null);


		// HACK: Destroyされるタイミングがイマイチ
		// 		 半透明でFadeする際の切り替えでちらつきがある(滑らかじゃない)
		// 		 現状でもまれに発生するが読み込むObjectが多い場合時間がかかるので
		// 		 結局ちらつく可能性がある
		// 		 その場合は非同期でのシーン切り替えを実装する必要がある
		Destroy(gameObject, Time.deltaTime);
	}


	private void ExceptionDetection(int sceneNumber)
	{
		if (IsFade) return;
		bool isOutOfRange = (sceneName_.Length - 1) < sceneNumber;
		Assert.IsFalse(isOutOfRange && !isMultiple_, 
		               "致命的なエラー : 単体モードです。");
		
		Assert.IsFalse(isOutOfRange && isMultiple_, 
		               "致命的なエラー : 登録されているSceneの数が少ないです。");
	}


	private void SetCameraMaterial(Material cameraMaterial)
	{
		// HACK: 冗長的
		// 		 MainCameraの取得はTagで行っている
		if (fadeTargetCamera_ == null)
		{
			if (Camera.main.GetComponent<FadeCameraRenderScript>() == null)
			{
				Camera.main.gameObject.AddComponent<FadeCameraRenderScript>();
			}

			Camera.main.GetComponent<FadeCameraRenderScript>().SetMaterial(cameraMaterial);
		} 
		else
		{
			if (fadeTargetCamera_.GetComponent<FadeCameraRenderScript>() == null)
			{
				fadeTargetCamera_.gameObject.AddComponent<FadeCameraRenderScript>();
			}

			fadeTargetCamera_.GetComponent<FadeCameraRenderScript>().SetMaterial(cameraMaterial);
		}
	}



	private void SetFade(bool fadeFlg)
	{
		isFadeOn_ = fadeFlg;
	}


	public void SetFadeCanvas(Canvas fadeCanvas)
	{
		int fadeTargetCanvasCount = 0;

		while (fadeTargetCanvasCount < fadeTargetCanvasList_.Count)
		{
			if (fadeTargetCanvasList_[fadeTargetCanvasCount] != null && fadeTargetCanvasList_[fadeTargetCanvasCount].GetInstanceID() == fadeCanvas.GetInstanceID()) return;

			fadeTargetCanvasCount++;
		}
		fadeTargetCanvasCount = 0;

		while (fadeTargetCanvasCount < fadeTargetCanvasList_.Count)
		{
			if (fadeTargetCanvasList_[fadeTargetCanvasCount] == null) 
			{
				fadeTargetCanvasList_ [fadeTargetCanvasCount] = fadeCanvas;
				return;
			}
			fadeTargetCanvasCount++;
		}
		fadeTargetCanvasCount = 0;


		fadeTargetCanvasList_.Add(fadeCanvas);
	}



	public bool IsFade
	{
		get
		{
			return isFadeOn_;
		}
	}

	public string SceneName
	{
		get
		{
			return SceneManager.GetActiveScene().name;
		}
	}
}