﻿using UnityEngine;

public class SceneNameAttribute : PropertyAttribute 
{
	public int sceneIndex_ = 0;

	public SceneNameAttribute()
	{
	}
}