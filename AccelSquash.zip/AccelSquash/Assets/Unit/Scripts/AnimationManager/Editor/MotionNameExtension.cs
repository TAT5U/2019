﻿#if UNITY_EDITOR
using UnityEngine;
using UnityEditor.Animations;
using System.Collections.Generic;
using UnityEditor;


[CustomPropertyDrawer(typeof(MotionNameAttribute), true)]
public class MotionNameExtension : PropertyDrawer 
{
	private List<Motion> motions_ = new List<Motion>();
	private List<string> motionNames_ = new List<string>();
	private List<int> motionNumbers_ = new List<int>();


	public override void OnGUI(Rect rect, SerializedProperty property, GUIContent content)
	{
		content.text = "MotionName";


		AnimationManagerScript animManager = (AnimationManagerScript)property.serializedObject.targetObject;

		AnimatorController animController = animManager.GetAnimatorController;

		if (animController == null) return;


		// 今回はレイヤーを使用しないので、強制的に先頭のレイヤーを使用
		MotionSearch(animController.layers[0].stateMachine);

		Motion[] motions = motions_.ToArray();
		string[] motionNames = motionNames_.ToArray();
		int[] motionNumbers = motionNumbers_.ToArray();


		if (property.objectReferenceValue != null)
		{
			ApplyLastSetting(motionNames, property.objectReferenceValue.name);
		}

		attributeName.motionIndex_ = EditorGUI.IntPopup(rect, content.text, attributeName.motionIndex_, motionNames, motionNumbers);

		if (motions.Length <= 0) return;
		property.objectReferenceValue = (AnimationClip)motions[attributeName.motionIndex_];
	}

	private void MotionSearch(AnimatorStateMachine state)
	{
		int nullCount = 0;
		for (int i = 0; i < state.states.Length; i++)
		{

			if (state.states[i].state.motion == null)
			{
				nullCount++;
			}
			else
			{
				motions_.Add(state.states[i].state.motion);
				motionNames_.Add(state.states[i].state.motion.name);
				motionNumbers_.Add(i - nullCount);
			}
		}
	}

	private void ApplyLastSetting(string[] scenes, string lastScene)
	{
		if (!IsLastSetting(lastScene)) return;
		attributeName.motionIndex_ = LastSceneIndex(scenes, lastScene);
	}

	private int LastSceneIndex(string[] scenes, string lastScene)
	{
		int sceneIndex = 0;
		bool sceneDetection = false;
		foreach (string sceneName in scenes)
		{
			if (sceneName == lastScene)
			{
				sceneDetection = true;
				break;
			}
			sceneIndex++;
		}
		return sceneDetection ? sceneIndex : 0;
	}


	private bool IsLastSetting(string lastScene)
	{
		return !string.IsNullOrEmpty(lastScene);
	}

	// 省略化
	private MotionNameAttribute attributeName
	{
		get
		{
			return (MotionNameAttribute)attribute;
		}
	}
}
#endif
