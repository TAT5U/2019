﻿#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;


[CustomPropertyDrawer(typeof(TextureMotionNameAttribute), true)]
public class TextureMotionNameExtension : PropertyDrawer 
{
	private string[] textureMotionNames_;
	private int[] textureMotionNumbers_;


	public override void OnGUI(Rect rect, SerializedProperty property, GUIContent content)
	{
		content.text = "TextureMotionName";


		TextureAnimationManagerScript textureAnimationManagerScript = (TextureAnimationManagerScript)property.serializedObject.targetObject;

		if (textureAnimationManagerScript == null) return;


		TextureMotionSearch(textureAnimationManagerScript);

		string[] textureMotionNames = textureMotionNames_;
		int[] textureMotionNumbers = textureMotionNumbers_;


		if (property.stringValue != null)
		{
			ApplyLastSetting(textureMotionNames, property.stringValue);
		}

		attributeName.textureMotionIndex_ = EditorGUI.IntPopup(rect, content.text, attributeName.textureMotionIndex_, textureMotionNames, textureMotionNumbers);

		if (textureMotionNames.Length <= 0) return;
		property.stringValue = textureMotionNames[attributeName.textureMotionIndex_];
	}

	private void TextureMotionSearch(TextureAnimationManagerScript textureAnimationManagerScript)
	{
		textureMotionNames_ = textureAnimationManagerScript.GetAnimationNames;
		textureMotionNumbers_ = new int[textureMotionNames_.Length];
		for (int textureMotionCount = 0; textureMotionCount < textureMotionNames_.Length; textureMotionCount++)
		{
			textureMotionNumbers_[textureMotionCount] = textureMotionCount;
		}
	}

	private void ApplyLastSetting(string[] scenes, string lastScene)
	{
		if (!IsLastSetting(lastScene)) return;
		attributeName.textureMotionIndex_ = LastSceneIndex(scenes, lastScene);
	}

	private int LastSceneIndex(string[] scenes, string lastScene)
	{
		int sceneIndex = 0;
		bool sceneDetection = false;
		foreach (string sceneName in scenes)
		{
			if (sceneName == lastScene)
			{
				sceneDetection = true;
				break;
			}
			sceneIndex++;
		}
		return sceneDetection ? sceneIndex : 0;
	}


	private bool IsLastSetting(string lastScene)
	{
		return !string.IsNullOrEmpty(lastScene);
	}

	// 省略化
	private TextureMotionNameAttribute attributeName
	{
		get
		{
			return (TextureMotionNameAttribute)attribute;
		}
	}
}
#endif
