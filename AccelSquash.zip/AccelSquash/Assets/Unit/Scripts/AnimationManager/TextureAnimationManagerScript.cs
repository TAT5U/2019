﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class TextureAnimationManagerScript : MonoBehaviour 
{
	[SerializeField]
	private bool isChildAnimation_ = false;

	[SerializeField, TextureMotionName]
	private string[] textureMotion_ = new string[2];


	private AnimatedMeshScript animatedMeshScript_;
	private AnimatedMeshScript[] animatedMeshChildScripts_;

	private int animatedMeshChildCount_ = 0;

	private int animationIndex_ = -1;


	#if UNITY_EDITOR
	public string[] GetAnimationNames
	{
		get
		{
			return GetComponent<AnimatedMeshScript>().GetAnimationNames;
		}
	}


	private void OnValidate()
	{
		GetComponent<AnimatedMeshScript>().SetAnimationCheckName(textureMotion_[0]);


		if (!isChildAnimation_) return;
		animatedMeshChildCount_ = 0;
		while (animatedMeshChildCount_ < GetComponentsInChildren<AnimatedMeshScript>().Length)
		{
			GetComponentsInChildren<AnimatedMeshScript>()[animatedMeshChildCount_].SetAnimationCheckName(textureMotion_[0]);
			animatedMeshChildCount_++;
		}
	}
	#endif



	protected virtual void Awake()
	{
		animatedMeshScript_ = GetComponent<AnimatedMeshScript>();

		if (!isChildAnimation_) return;
		animatedMeshChildScripts_ = GetComponentsInChildren<AnimatedMeshScript>();
	}


	private void AnimationCrossFade()
	{
		//if (!graph_.IsPlaying())
		//{
		//	graph_.Play();
		//}


		//if (speed_ < 1.0f)
		//{
		//	isAnimationCrossFade_ = true;

		//	mixer_.SetInputWeight(0, 1 - speed_);
		//	mixer_.SetInputWeight(1, speed_);
		//	speed_ += crossFadeSpeed_;
		//	StartCoroutine(this.InvokeExRealTimeUpdate(AnimationCrossFade));
		//}
		//else
		//{
		//	isAnimationCrossFade_ = false;
		//	speed_ = 0.0f;

		//	mixer_.SetInputWeight(0, speed_);
		//	mixer_.SetInputWeight(1, 1 - speed_);
		//}
	}


	protected void AnimationStart(int animationIndex, bool compPlay = false, float animationSpeed = 1.0f)
	{
		if (animatedMeshScript_ == null || animatedMeshScript_.IsAnimationCheck) return;


		if (animationIndex_ == animationIndex) return;

		animationIndex_ = animationIndex;


		animatedMeshScript_.Stop();

		animatedMeshScript_.Play(textureMotion_[animationIndex], 0.0f);

		if (!isChildAnimation_) return;
		animatedMeshChildCount_ = 0;
		while (animatedMeshChildCount_ < animatedMeshChildScripts_.Length)
		{
			animatedMeshChildScripts_[animatedMeshChildCount_].Play(textureMotion_[animationIndex], 0.0f);
			animatedMeshChildCount_++;
		}

		//if (isAnimationCrossFade_ || !isAnimationComplete_ || animationIndex_ == animationIndex) return;


		//animationIndex_ = animationIndex;

		//graph_.Disconnect(mixer_, 0);
		//graph_.Disconnect(mixer_, 1);
		//if (prevAnimationPlayable_.IsValid())
		//{
		//	prevAnimationPlayable_.Destroy();
		//}

		//prevAnimationPlayable_ = nowAnimationPlayable_;
		//nowAnimationPlayable_ = AnimationClipPlayable.Create(graph_, motion[animationIndex]);

		//mixer_.ConnectInput(0, prevAnimationPlayable_, 0);
		//mixer_.ConnectInput(1, nowAnimationPlayable_, 0);

		//mixer_.SetSpeed(animationSpeed);
		//output_.SetSourcePlayable(mixer_);


		//AnimationCrossFade();


		//if (compPlay)
		//{
		//	animationCompleteTime_ = 0.0f;
		//	isAnimationComplete_ = false;
		//	AnimationCompleteMonitor();
		//}
	}

	protected void AnimationStop()
	{
		if (animatedMeshScript_ == null || animatedMeshScript_.IsAnimationCheck) return;

		animatedMeshScript_.Stop();

		if (!isChildAnimation_) return;
		animatedMeshChildCount_ = 0;
		while (animatedMeshChildCount_ < animatedMeshChildScripts_.Length)
		{
			animatedMeshChildScripts_[animatedMeshChildCount_].Stop();
			animatedMeshChildCount_++;
		}
		//StopCoroutine(this.InvokeExRealTimeUpdate(AnimationCrossFade));
		//speed_ = 0.0f;
		//graph_.Stop();
	}


	private void AnimationCompleteMonitor()
	{
		//animationCompleteTime_ += Time.deltaTime;
		//if (animationCompleteTime_ >= (motion[animationIndex_].length / mixer_.GetSpeed()))
		//{
		//	isAnimationComplete_ = true;
		//	return;
		//}
		//StartCoroutine(this.InvokeExRealTimeUpdate(AnimationCompleteMonitor));
	}


	//protected bool IsAnimationCrossFade
	//{
	//	get
	//	{
	//		return isAnimationCrossFade_;
	//	}
	//}

	//protected bool IsAnimationComplete
	//{
	//	get
	//	{
	//		return isAnimationComplete_;
	//	}
	//}


	//protected int GetAnimationIndex
	//{
	//	get
	//	{
	//		return animationIndex_;
	//	}
	//}


	//private void OnDestroy()
	//{
	//	graph_.Destroy();
	//}
}
