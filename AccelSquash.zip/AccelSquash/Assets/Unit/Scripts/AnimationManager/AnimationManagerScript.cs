﻿using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.Playables;


#if UNITY_EDITOR
using UnityEditor.Animations;
#endif



[RequireComponent(typeof(Animator))]
public abstract class AnimationManagerScript : MonoBehaviour
{
	[SerializeField, MotionName]
	private AnimationClip[] motion_ = new AnimationClip[2];

	[SerializeField]
	private float crossFadeSpeed_ = 0.50f;


	private int animationIndex_ = -1;


	private Animator animator_ = null;
	private PlayableGraph graph_;

	private AnimationClipPlayable prevAnimationPlayable_;
	private AnimationClipPlayable nowAnimationPlayable_;

	private AnimationMixerPlayable mixer_;
	private AnimationPlayableOutput output_;
	private Playable playable;


	private bool isAnimationCrossFade_ = false;
	private bool isAnimationComplete_  = true;

	private float speed_ = 0.0f;
	private float animationCompleteTime_ = 0.0f;


	#if UNITY_EDITOR
	[SerializeField]
	private AnimatorController animatorController_;

	public AnimatorController GetAnimatorController
	{
		get
		{
			return animatorController_;
		}
	}
	#endif



	protected virtual void Awake()
	{
		animator_ = GetComponent<Animator>();


		graph_ = PlayableGraph.Create();


		AnimatorControllerPlayable animatorControllerPlayable = AnimatorControllerPlayable.Create(graph_, animator_.runtimeAnimatorController);

		mixer_ = AnimationMixerPlayable.Create(graph_, 2, true);
		mixer_.ConnectInput(0, animatorControllerPlayable, 0);

		output_ = AnimationPlayableOutput.Create(graph_, "output", animator_);
		output_.SetSourcePlayable(mixer_);
		graph_.Play();
	}


	private void AnimationCrossFade()
	{
		if (!graph_.IsPlaying())
		{
			graph_.Play();
		}


		if (speed_ < 1.0f)
		{
			isAnimationCrossFade_ = true;
			
			mixer_.SetInputWeight(0, 1 - speed_);
			mixer_.SetInputWeight(1, speed_);
			speed_ += crossFadeSpeed_;
			StartCoroutine(this.InvokeExRealTimeUpdate(AnimationCrossFade));
		}
		else
		{
			isAnimationCrossFade_ = false;
			speed_ = 0.0f;

			mixer_.SetInputWeight(0, speed_);
			mixer_.SetInputWeight(1,1 - speed_);
		}
	}


	protected void AnimationStart(int animationIndex, bool compPlay = false, float animationSpeed = 1.0f)
	{
		if (isAnimationCrossFade_ || !isAnimationComplete_ || animationIndex_ == animationIndex) return;


		animationIndex_ = animationIndex;

		graph_.Disconnect(mixer_, 0);
		graph_.Disconnect(mixer_, 1);
		if (prevAnimationPlayable_.IsValid())
		{
			prevAnimationPlayable_.Destroy();
		}

		prevAnimationPlayable_ = nowAnimationPlayable_;
		nowAnimationPlayable_ = AnimationClipPlayable.Create(graph_, motion_[animationIndex]);


		mixer_.ConnectInput(0, prevAnimationPlayable_, 0);
		mixer_.ConnectInput(1, nowAnimationPlayable_, 0);

		mixer_.SetSpeed(animationSpeed);
		output_.SetSourcePlayable(mixer_);


		AnimationCrossFade();


		if (compPlay)
		{
			animationCompleteTime_ = 0.0f;
			isAnimationComplete_ = false;
			AnimationCompleteMonitor();
		}
	}

	protected void AnimationStop()
	{
		StopCoroutine(this.InvokeExRealTimeUpdate(AnimationCrossFade));
		speed_ = 0.0f;
		graph_.Stop();
	}


	private void AnimationCompleteMonitor()
	{
		animationCompleteTime_ += Time.deltaTime;
		if (animationCompleteTime_ >= (motion_[animationIndex_].length / mixer_.GetSpeed()))
		{
			isAnimationComplete_ = true;
			return;
		}
		StartCoroutine(this.InvokeExRealTimeUpdate(AnimationCompleteMonitor));
	}


	protected bool IsAnimationCrossFade
	{
		get
		{
			return isAnimationCrossFade_;
		}
	}

	protected bool IsAnimationComplete
	{
		get
		{
			return isAnimationComplete_;
		}
	}


	protected int GetAnimationIndex
	{
		get
		{
			return animationIndex_;
		}
	}


	private void OnDestroy()
	{
		graph_.Destroy();
	}
}
