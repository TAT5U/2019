﻿using UnityEngine;

public class TextureMotionNameAttribute : PropertyAttribute 
{
	public int textureMotionIndex_;
}
