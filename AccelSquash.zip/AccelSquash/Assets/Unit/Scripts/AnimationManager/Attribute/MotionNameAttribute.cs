﻿using UnityEngine;


public class MotionNameAttribute : PropertyAttribute
{
	public int motionIndex_;
}
