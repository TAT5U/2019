﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class DontDestroyManagerScript<ClassType> : SingletonScript<DontDestroyManagerScript<ClassType>> where ClassType : DontDestroyManagerScript<ClassType>
{
	protected override void Awake()
	{
		base.Awake();

		DontDestroyOnLoad(gameObject);

		CheckInstanceState();
	}
}
