﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneBranchManagerScript : SingletonScript<SceneBranchManagerScript> 
{
	public enum GameSceneBranch
	{
		ScoreAttack,
		Practice
	}

	private GameSceneBranch gameSceneBranch_ = GameSceneBranch.ScoreAttack;


	protected override void Awake()
	{
		base.Awake();
		DontDestroyOnLoad(gameObject);
	}


	public void SetGameSceneBranch(GameSceneBranch gameSceneBranch)
	{
		gameSceneBranch_ = gameSceneBranch;
	}

	public GameSceneBranch GetGameSceneBranch
	{
		get
		{
			return gameSceneBranch_;
		}
	}
}
