﻿using UnityEngine;
using System.Collections.Generic;


public abstract class AnimationInfoScript :MonoBehaviour
{
	[SerializeField, CustomReadOnly]
	protected string[] animationNames_;

	[SerializeField, CustomReadOnly]
	protected int[] animationStartFrames_;

	[SerializeField, CustomReadOnly]
	protected int[] animationEndFrames_;

	[SerializeField, CustomReadOnly]
	protected int[] animationFrameCounts_;


	[SerializeField, HideInInspector]
	private int animationCount_ = 0;

	[SerializeField, HideInInspector]
	private bool isApply_ = false;


	private List<string> animationNameList_	   = new List<string>();
	private List<int> animationStartFrameList_ = new List<int>();
	private List<int> animationEndFrameList_   = new List<int>();
	private List<int> animationFrameCountList_ = new List<int>();


	private void OnValidate()
	{
		if (!isApply_) return;

		if (animationNames_.Length != animationCount_ || animationStartFrames_.Length != animationCount_ || animationEndFrames_.Length != animationCount_ || animationFrameCounts_.Length != animationCount_)
		{
			System.Array.Resize(ref animationNames_, animationCount_);
			System.Array.Resize(ref animationStartFrames_, animationCount_);
			System.Array.Resize(ref animationEndFrames_, animationCount_);
			System.Array.Resize(ref animationFrameCounts_, animationCount_);
		}
	}


	public void SetAnimationInfo(string animationName, int animationStartFrame, int animationEndFrame, int animationFrameCount)
	{
		animationNameList_.Add(animationName);
		animationStartFrameList_.Add(animationStartFrame);
		animationEndFrameList_.Add(animationEndFrame);
		animationFrameCountList_.Add(animationFrameCount);

		animationCount_++;
	}

	public void AnimationInfoApply()
	{
		animationNames_		  = animationNameList_.ToArray();
		animationStartFrames_ = animationStartFrameList_.ToArray();
		animationEndFrames_	  = animationEndFrameList_.ToArray();
		animationFrameCounts_ = animationFrameCountList_.ToArray();

		isApply_ = true;
	}


	public string[] GetAnimationNames
	{
		get
		{
			return animationNames_;
		}
	}

}
