﻿#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

[ExecuteInEditMode]
public class AnimatedMeshConverterScript : ScriptableWizard 
{
	[SerializeField]
	private GameObject targetObject_;

	[SerializeField]
	private string convertPath_ = "AnimatedMesh";

	[SerializeField]
	private string convertObjectName_ = "";


	private string shaderName_ = "Custom/AnimationMeshShader";

	private const int kTargetFrameRate	  = 30;
	private const int kBoneMatrixRowCount = 3;

	private bool isNameSet_ = false;


	[MenuItem("AnimatedMesh/Convert")]
	private static void Open()
	{
		DisplayWizard<AnimatedMeshConverterScript>("AnimatedMeshConverter");
	}

	private void OnWizardCreate()
	{
		AnimatedMeshConvert();
	}

	private void OnWizardUpdate()
	{
		if (targetObject_ == null || isNameSet_) return;
		convertObjectName_ = targetObject_.name;
		isNameSet_ = true;
	}


	private void AnimatedMeshConvert()
	{
	    if (targetObject_ == null)
	    {
	        EditorUtility.DisplayDialog("Warning", "No Select Gameobject.", "OK");
	        return;
	    }
	    

		SkinnedMeshRenderer[] skinnedMeshRenderers = targetObject_.GetComponentsInChildren<SkinnedMeshRenderer>();


		if (skinnedMeshRenderers == null || skinnedMeshRenderers.Length != 1)
	    {
	        EditorUtility.DisplayDialog("Warning", "No Component SkinnedMeshRenderer or, \nPlural Componented SkinnedMeshRenderer.", "OK");
	        return;
	    }

	    Animator animator = targetObject_.GetComponentInChildren<Animator>();
	    if (animator == null)
	    {
	        EditorUtility.DisplayDialog("Warning", "No Component Animator.", "OK");
	        return;
	    }


	    string targetObjectPath = Path.GetDirectoryName(AssetDatabase.GetAssetPath(targetObject_));


		//int skinIndex = 0;
		//foreach (var skin in skinnedMeshRenderers)
		//{
			SkinnedMeshRenderer skinnedMeshRenderer = skinnedMeshRenderers[0];
			AnimationClip[] animationClips = animator.runtimeAnimatorController.animationClips;


			Directory.CreateDirectory(Path.Combine(targetObjectPath, convertPath_));



			string name = convertObjectName_;
			//if (skinIndex > 0)
			//{
				//name += (skinIndex.ToString());

				//Texture animationTexture = ConvertAnimationTexture(skin.transform.parent.gameObject, animationClips, skin);
				//Mesh animationMesh = ConvertBoneWeightMesh(skin);
				//Material animationMaterial = ConvertMaterial(skin, animationTexture, skin.bones.Length);
				//GameObject convertObject = ConvertObject(animationMesh, animationMaterial, animationClips);

				//Create(name, targetObjectPath, animationTexture, animationMesh, animationMaterial, convertObject);


				//DestroyImmediate(convertObject);

			//}
			//else
			//{
				Texture animationTexture = ConvertAnimationTexture(targetObject_, animationClips, skinnedMeshRenderer);
				Mesh animationMesh = ConvertBoneWeightMesh(skinnedMeshRenderer);
				Material animationMaterial = ConvertMaterial(skinnedMeshRenderer, animationTexture, skinnedMeshRenderer.bones.Length);
				GameObject convertObject = ConvertObject(animationMesh, animationMaterial, animationClips);

				Create(name, targetObjectPath, animationTexture, animationMesh, animationMaterial, convertObject);


				DestroyImmediate(convertObject);

			//}
			//skinIndex++;
		//}


	}

	private Mesh ConvertBoneWeightMesh(SkinnedMeshRenderer skinnedMeshRenderer)
	{
		Mesh boneWeightMesh = Instantiate(skinnedMeshRenderer.sharedMesh);


		BoneWeight[] boneWeights = skinnedMeshRenderer.sharedMesh.boneWeights;

		List<Vector4> boneIndexList  = new List<Vector4>();
		List<Vector4> boneWeightList = new List<Vector4>();


		int boneWeightIndex = 0;
		while (boneWeightIndex < boneWeights.Length)
		{
			boneIndexList.Add(new Vector4(boneWeights[boneWeightIndex].boneIndex0, boneWeights[boneWeightIndex].boneIndex1, boneWeights[boneWeightIndex].boneIndex2, boneWeights[boneWeightIndex].boneIndex3));
			boneWeightList.Add(new Vector4(boneWeights[boneWeightIndex].weight0, boneWeights[boneWeightIndex].weight1, boneWeights[boneWeightIndex].weight2, boneWeights[boneWeightIndex].weight3));
			boneWeightIndex++;
		}


		boneWeightMesh.SetUVs(2, boneIndexList);
		boneWeightMesh.SetUVs(3, boneWeightList);

		return boneWeightMesh;
	}

	private Texture ConvertAnimationTexture(GameObject targetObject, AnimationClip[] animationClips, SkinnedMeshRenderer skinnedMeshRenderer)
	{
		Vector2 animationTextureBound = GetTextureBound(animationClips, skinnedMeshRenderer.bones.Length);

		Texture2D animationTexture = new Texture2D((int)animationTextureBound.x, (int)animationTextureBound.y, TextureFormat.RGBAHalf, false, true);
		Color[] pixels = animationTexture.GetPixels();
		int pixelIndex = 0;


		int bindPoseIndex = 0;

		while (bindPoseIndex < skinnedMeshRenderer.bones.Length)
		{
			Matrix4x4 boneMatrix = skinnedMeshRenderer.bones[bindPoseIndex].localToWorldMatrix * skinnedMeshRenderer.sharedMesh.bindposes[bindPoseIndex];

			pixels[pixelIndex++] = new Color(boneMatrix.m00, boneMatrix.m01, boneMatrix.m02, boneMatrix.m03);
			pixels[pixelIndex++] = new Color(boneMatrix.m10, boneMatrix.m11, boneMatrix.m12, boneMatrix.m13);
			pixels[pixelIndex++] = new Color(boneMatrix.m20, boneMatrix.m21, boneMatrix.m22, boneMatrix.m23);

			
			bindPoseIndex++;
		}


		// HACK: ネストが複雑
		int animationClipIndex = 0;

		while (animationClipIndex < animationClips.Length)
		{
			int totalFrame = (int)(animationClips[animationClipIndex].length * kTargetFrameRate);

			int frame = 0;
			while (frame < totalFrame)
			{
				animationClips[animationClipIndex].SampleAnimation(targetObject, (float)frame / kTargetFrameRate);

				bindPoseIndex = 0;

				while (bindPoseIndex < skinnedMeshRenderer.bones.Length)
				{
					Matrix4x4 boneMatrix = skinnedMeshRenderer.bones[bindPoseIndex].localToWorldMatrix * skinnedMeshRenderer.sharedMesh.bindposes[bindPoseIndex];

					pixels[pixelIndex++] = new Color(boneMatrix.m00, boneMatrix.m01, boneMatrix.m02, boneMatrix.m03);
					pixels[pixelIndex++] = new Color(boneMatrix.m10, boneMatrix.m11, boneMatrix.m12, boneMatrix.m13);
					pixels[pixelIndex++] = new Color(boneMatrix.m20, boneMatrix.m21, boneMatrix.m22, boneMatrix.m23);

					bindPoseIndex++;
				}
				frame++;
			}
			animationClipIndex++;
		}


		animationTexture.SetPixels(pixels);
		animationTexture.Apply();
		animationTexture.filterMode = FilterMode.Point;

		return animationTexture;
	}

	private Vector2 GetTextureBound(AnimationClip[] animationClips, int boneLength)
	{
		int boneMatrixCount = kBoneMatrixRowCount * boneLength;

		int totalPixels = boneMatrixCount;


		int animationClipIndex = 0;

		while (animationClipIndex < animationClips.Length)
		{
			totalPixels += boneMatrixCount * (int)(animationClips[animationClipIndex].length * kTargetFrameRate);
			animationClipIndex++;
		}


		int textureWidth  = 1;
		int textureHeight = 1;

		while (textureWidth * textureHeight < totalPixels)
		{
			if (textureWidth <= textureHeight)
			{
				textureWidth *= 2;
			}
			else
			{
				textureHeight *= 2;
			}
		}

		return new Vector2(textureWidth, textureHeight);
	}

	private Material ConvertMaterial(SkinnedMeshRenderer skinnedMeshRenderer, Texture texture, int boneLength)
	{
		Material material = Instantiate(skinnedMeshRenderer.sharedMaterial);
		material.shader = Shader.Find(shaderName_);
		material.SetTexture("_AnimationTex", texture);
		material.SetInt("pixelCountPerFrame_", kBoneMatrixRowCount * boneLength);
		material.enableInstancing = true;

		return material;
	}

	private GameObject ConvertObject(Mesh mesh, Material material, AnimationClip[] animationClips)
	{
		GameObject convertObject = new GameObject();
		convertObject.name = convertObjectName_;

		MeshFilter[] meshFilters_ = targetObject_.GetComponentsInChildren<MeshFilter>();
		if (meshFilters_.Length > 1)
		{
			CombineInstance[] combine = new CombineInstance[meshFilters_.Length];
			
			int meshCount = 0;
			foreach (var item in meshFilters_)
			{
				Debug.Log("Mesh Combine!!");
				if (meshCount <= 0)
				{
					Debug.Log("Init Mesh!!");
					combine[meshCount].mesh = mesh;
					combine[meshCount].transform = item.transform.localToWorldMatrix;
				}
				else
				{
					Debug.Log("Other Mesh!!");
					combine[meshCount].mesh = item.sharedMesh;
					combine[meshCount].transform = item.transform.localToWorldMatrix;
				}

				item.gameObject.SetActive(false);
				meshCount++;
			}

			MeshFilter meshFilter = convertObject.AddComponent<MeshFilter>();
			meshFilter.mesh = new Mesh();
			meshFilter.mesh.CombineMeshes(combine);
			convertObject.gameObject.SetActive(true);
			Debug.Log("Combine!!");
		}
		else
		{
			MeshFilter meshFilter = convertObject.AddComponent<MeshFilter>();
			meshFilter.mesh = mesh;
		}




		MeshRenderer meshRenderer = convertObject.AddComponent<MeshRenderer>();
		meshRenderer.sharedMaterial 			= material;
		meshRenderer.motionVectorGenerationMode = MotionVectorGenerationMode.ForceNoMotion;
		meshRenderer.reflectionProbeUsage	    = ReflectionProbeUsage.Off;
		meshRenderer.lightProbeUsage	  		= LightProbeUsage.Off;
		meshRenderer.shadowCastingMode	  		= ShadowCastingMode.Off;
		meshRenderer.receiveShadows 			= false;


		AnimatedMeshScript animtedMeshRenderer = convertObject.AddComponent<AnimatedMeshScript>();


		int currentClipFrame = 0;
		int animationClipIndex = 0;

		while (animationClipIndex < animationClips.Length)
		{
			int frameCount = (int)(animationClips[animationClipIndex].length * kTargetFrameRate);
			int startFrame = currentClipFrame + 1;
			int endFrame = startFrame + frameCount - 1;

			animtedMeshRenderer.SetAnimationInfo(animationClips[animationClipIndex].name, startFrame, endFrame, frameCount);
			currentClipFrame = endFrame;

			animationClipIndex++;
		}

		animtedMeshRenderer.AnimationInfoApply();


		return convertObject;
	}


	private void Create(string convertObjectName, string path, Texture animationTexture, Mesh animationMesh, Material animationMaterial, GameObject convertObject)
	{
		AssetDatabase.CreateAsset(animationTexture, (path + "/" + convertPath_ + "/" + convertObjectName + "_AnimationTexture.asset"));
		AssetDatabase.CreateAsset(animationMesh, (path + "/" + convertPath_ + "/" + convertObjectName + "_Mesh.asset"));
		AssetDatabase.CreateAsset(animationMaterial, (path + "/" + convertPath_ + "/" + convertObjectName + "_Material.asset"));
		PrefabUtility.CreatePrefab((path + "/" + convertPath_ + "/" + convertObjectName + ".prefab"), convertObject);
	}
}
#endif
