﻿using UnityEngine;


[RequireComponent(typeof(Renderer))]
public class AnimatedMeshScript : AnimationInfoScript 
{
	[SerializeField]
	private bool isAnimationCheck_ = false;


	private Renderer renderer_;

	private bool isInitialize_ = false;
	private bool isPlay_ = false;

#if UNITY_EDITOR


	[SerializeField, Range(0.0f, 1.0f)]
	private float animationFrameRange_ = 0.0f;


	private string animationFrameName_ = "";

	private int animatedMeshChildCount_ = 0;


	// HACK: 冗長的かつ長すぎる
	// TODO: 関数化
	private void OnValidate()
	{
		if (!Application.isPlaying) return;
		AnimatedMeshScript[] animatedMeshChildScripts = GetComponentsInChildren<AnimatedMeshScript>();


		// HACK: 順番が子から設定されている
		// TODO: 親から子の流れで設定できるように変更
		animatedMeshChildCount_ = 0;
		while (animatedMeshChildCount_ < animatedMeshChildScripts.Length)
		{
			if (!animatedMeshChildScripts[animatedMeshChildCount_].IsAnimationCheck)
			{
				animatedMeshChildScripts[animatedMeshChildCount_].GetComponent<Renderer>().material.SetFloat("startFrame_", 0);
				animatedMeshChildScripts[animatedMeshChildCount_].GetComponent<Renderer>().material.SetFloat("endFrame_", 0);
				animatedMeshChildScripts[animatedMeshChildCount_].GetComponent<Renderer>().material.SetFloat("frameCount_", 1);
				animatedMeshChildScripts[animatedMeshChildCount_].SetAnimationFrameRange(0.0f);
			}
			animatedMeshChildCount_++;
		}


		if (!isAnimationCheck_ || animationFrameName_ == "")
		{
			
			GetComponent<Renderer>().material.SetFloat("startFrame_", 0);
			GetComponent<Renderer>().material.SetFloat("endFrame_", 0);
			GetComponent<Renderer>().material.SetFloat("frameCount_", 1);
			SetAnimationFrameRange(0.0f);
			return;
		}


		int animationCount = 0;

		while (animationCount < animationNames_.Length)
		{
			if (animationNames_[animationCount] == animationFrameName_)
			{
				Debug.Log(animationNames_[animationCount] + ", " + animationFrameCounts_[animationCount]);


				Debug.Log("Count = " + animationFrameCounts_[animationCount] * (animationFrameRange_));
				break;
			}
			animationCount++;
		}

		GetComponent<Renderer>().material.SetFloat("offset_", 0);
		GetComponent<Renderer>().material.SetFloat("startFrame_", animationStartFrames_[animationCount] + (animationFrameCounts_[animationCount] * animationFrameRange_));
		GetComponent<Renderer>().material.SetFloat("endFrame_", animationStartFrames_[animationCount] + (animationFrameCounts_[animationCount] * animationFrameRange_));
		GetComponent<Renderer>().material.SetFloat("frameCount_", 1);


		animatedMeshChildCount_ = 0;
		while (animatedMeshChildCount_ < animatedMeshChildScripts.Length)
		{
			if (animatedMeshChildScripts[animatedMeshChildCount_].IsAnimationCheck)
			{
				animatedMeshChildScripts[animatedMeshChildCount_].GetComponent<Renderer>().material.SetFloat("offset_", 0);
				animatedMeshChildScripts[animatedMeshChildCount_].GetComponent<Renderer>().material.SetFloat("startFrame_", animationStartFrames_[animationCount] + (animationFrameCounts_[animationCount] * animationFrameRange_));
				animatedMeshChildScripts[animatedMeshChildCount_].GetComponent<Renderer>().material.SetFloat("endFrame_", animationStartFrames_[animationCount] + (animationFrameCounts_[animationCount] * animationFrameRange_));
				animatedMeshChildScripts[animatedMeshChildCount_].GetComponent<Renderer>().material.SetFloat("frameCount_", 1);
				animatedMeshChildScripts[animatedMeshChildCount_].SetAnimationFrameRange(animationFrameRange_);
			}
			animatedMeshChildCount_++;
		}
	}


	public void SetAnimationCheckName(string animaionFrameName)
	{
		animationFrameName_ = animaionFrameName;
	}

	public void SetAnimationFrameRange(float animationFrameRange)
	{
		animationFrameRange_ = animationFrameRange;
	}
#endif
	public bool IsAnimationCheck
	{
		get
		{
			return isAnimationCheck_;
		}
	}


	private void Initialize()
	{
		renderer_ = GetComponent<Renderer>();

		isInitialize_ = true;
	}


	public void Play(string animationName, float offsetSeconds)
	{
		if (!isInitialize_)
		{
			Initialize();
		}


		int animationCount = 0;

		while (animationCount < animationNames_.Length)
		{
			if (animationNames_[animationCount] == animationName)
			{
				break;
			}
			animationCount++;
		}


		renderer_.material.SetFloat("offset_", offsetSeconds);
		renderer_.material.SetFloat("startFrame_", animationStartFrames_[animationCount]);
		renderer_.material.SetFloat("endFrame_", animationEndFrames_[animationCount]);
		renderer_.material.SetFloat("frameCount_", animationFrameCounts_[animationCount]);

		isPlay_ = true;
	}

	public void Stop()
	{
		if (!isInitialize_)
		{
			Initialize();
		}

		renderer_.material.SetFloat("startFrame_", 0);
		renderer_.material.SetFloat("endFrame_", 0);
		renderer_.material.SetFloat("frameCount_", 1);

		isPlay_ = false;
	}
}
