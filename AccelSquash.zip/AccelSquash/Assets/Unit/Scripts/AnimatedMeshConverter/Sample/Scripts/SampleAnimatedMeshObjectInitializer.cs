﻿using UnityEngine;

public class SampleAnimatedMeshObjectInitializer : MonoBehaviour
{
    //[SerializeField]
   // MaterialPropertyBlockController BodyPropertyBlockController;
    //[SerializeField]
    AnimatedMeshScript BodyMeshAnimator;
   // [SerializeField]
   // AnimatedMeshAnimator FaceMeshAnimator;

    private readonly static string[] RandomAnimationNames = new string[]
    {
  //      "Victory",
		//"Idle",
		//"Jump",
		//"ATK3",
		//"Basic_Run_03",
		"sword_idle",
    };

    private void Awake()
    {
		//BodyPropertyBlockController = GetComponent<MaterialPropertyBlockController>();
		BodyMeshAnimator = GetComponent<AnimatedMeshScript>();

        var randomColor = new Color(Random.Range(0.00f, 1.00f), Random.Range(0.00f, 1.00f), Random.Range(0.00f, 1.00f), 1);
      // BodyPropertyBlockController.SetColor("_Color", randomColor);
       // BodyPropertyBlockController.Apply();

		var offsetSeconds = 0.0f;//Random.Range(0.0f, 3.0f);
        var randomIndex = Random.Range(0, RandomAnimationNames.Length);
        var randomAnimationNames = RandomAnimationNames[randomIndex];


		Debug.Log(randomAnimationNames);
        BodyMeshAnimator.Play(randomAnimationNames, offsetSeconds);
        //FaceMeshAnimator.Play(randomAnimationNames, offsetSeconds);
    }
}
