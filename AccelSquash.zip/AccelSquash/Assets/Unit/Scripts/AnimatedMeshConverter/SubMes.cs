﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SubMes : MonoBehaviour 
{
	private Renderer rr;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		rr = gameObject.transform.parent.GetComponent<Renderer>();
		if (rr == null)
		{
			return;
		}


		float x = rr.material.GetFloat("subMeshOutPutPosX");
		float y = rr.material.GetFloat("subMeshOutPutPosY");
		float z = rr.material.GetFloat("subMeshOutPutPosZ");

		transform.position = new Vector3(x, y, z);

		rr.material.SetVector("subMeshInPutPos", new Vector4(x, y, z, 0.0f));
	}
}
