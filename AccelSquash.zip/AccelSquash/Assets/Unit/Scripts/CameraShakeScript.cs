﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraShakeScript : SingletonScript<CameraShakeScript> 
{
	[SerializeField, Range(0.0f, 1.0f)]
	private float shakeTime_;

	[SerializeField, Range(0.0f, 0.50f)]
	private float shakeRange_;


	private Vector3 startPos_ = new Vector3 (0.0f, 0.0f, 0.0f);

	private float time_;

	private bool isShake_ = false;


	protected override void Awake()
	{
		base.Awake();

		DontDestroyOnLoad(gameObject);

		CheckInstanceState();



	}

	private void Update()
	{
		if (!isShake_)
		{
			startPos_ = transform.localPosition;
			return;
		}

		time_ += Time.deltaTime;
		transform.localPosition += new Vector3 (Random.Range(-1.0f,1.0f) * shakeRange_, Random.Range(-1.0f, 1.0f) * shakeRange_, 0.0f);

		if (time_ >= shakeTime_)
		{
			transform.localPosition = startPos_;
			time_ = 0.0f;
			ShakeStop ();
		}
	}


	public void ShakeStart()
	{
		isShake_ = true;
	}

	public void ShakeStop()
	{
		isShake_ = false;
	}
}
